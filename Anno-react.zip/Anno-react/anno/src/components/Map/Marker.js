import React from "react";

const Marker = ({ icon }) => (
  <div>
    <img src={icon} alt="pin" />
  </div>
);

export default Marker;
